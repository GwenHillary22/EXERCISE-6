
<footer>
<pre>
Our Github Accounts
Gwen Hillary Otic:                    Angeline Perez:                   Alef Justin Loresca:                    Christa Bianca Cueno:                   Judel Colico: 
                        <a href="https://github.com/GwenHillary22"target="_blank">GwenHillary22</a>                         <a href="https://github.com/Angeline-perez" target="_blank">Angeline-perez</a>                            <a href="https://github.com/krobbus" target="_blank">krobbus</a>                               <a href="https://github.com/BiancakeCueno" target="_blank">BiancakeCueno</a>                      <a href="https://github.com/JudelColico" target="_blank">JudelColico</a>                          
    </pre>
</footer>
